package facade;

public class IOFacadeTest {
	
	public static void main(String[] args) {
		
		IOFacade.write("teste", "arquivo.txt");
	}
}
