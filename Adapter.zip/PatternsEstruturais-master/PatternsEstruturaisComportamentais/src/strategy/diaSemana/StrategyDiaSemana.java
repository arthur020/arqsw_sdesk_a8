package strategy.diaSemana;

public interface StrategyDiaSemana {
	
	void mensagemDia();
}
