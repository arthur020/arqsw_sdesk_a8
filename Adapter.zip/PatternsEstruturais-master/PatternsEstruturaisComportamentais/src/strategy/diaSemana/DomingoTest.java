package strategy.diaSemana;

public class DomingoTest {
	
	public static void main(String[] args) {
		Domingo domingo = new Domingo("Hoje � Domingo");
		domingo.mensagemDia();
	}
}
